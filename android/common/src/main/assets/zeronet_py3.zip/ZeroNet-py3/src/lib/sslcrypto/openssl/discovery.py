# Can be redefined by user
def discover():
	pass