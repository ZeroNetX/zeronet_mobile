import re
from Plugin import PluginManager

# Warning: If you modify the donation address then renmae the plugin's directory to "MyDonationMessage" to prevent the update script overwrite


@PluginManager.registerTo("UiRequest")
class UiRequestPlugin(object):
    # Inject a donation message to every page top right corner
    def renderWrapper(self, *args, **kwargs):
        body = super(UiRequestPlugin, self).renderWrapper(*args, **kwargs)  # Get the wrapper frame output

        inject_html = """
            <style>
             #donation_message {
                color: #AF3BFF;
                position: absolute;
                bottom: 20px;
                right: 0px;
                font-family: Roboto;
                font-size: 0.95em;
                font-weight: bold;
                background: white;
                opacity: 0.95;
                border-radius: 15px 0px 0px 15px;
                padding: 8px 2px 8px 10px;
            }
            </style>
            <a id='donation_message' href='https://blockchain.info/address/1eVStCWqLM7hFB1enaoGzAt7T3tsAB41z' target='_blank'>💖 Donate</a>
            </body>
            </html>
        """.encode()

        return re.sub(b"</body>\s*</html>\s*$", inject_html, body)