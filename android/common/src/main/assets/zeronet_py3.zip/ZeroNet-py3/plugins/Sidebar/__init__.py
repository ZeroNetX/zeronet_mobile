from . import SidebarPlugin
from . import ConsolePlugin