def transpile(code):
	return code