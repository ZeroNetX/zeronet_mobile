# PeerMessage

**PeerMessage** is a plugin for [ZeroNet](https://github.com/HelloZeroNet/ZeroNet), a decentralized network. It enables peer-to-peer communication via messages by extending ZeroFrame API and peer API.


Read more at [wiki](https://github.com/HelloZeroNet/Plugin-PeerMessage/wiki).